const express = require('express');
const passport = require('passport');
const session = require('express-session');

const LocalStrategy = require('passport-local').Strategy;

const app = express();

const users = require('./users.json');

app.use(session({
  secret: 'secret-key',
  resave: false,
  saveUninitialized: false
}));

app.use(passport.initialize());
app.use(passport.session());
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

passport.use(new LocalStrategy(
  function(username, password, done) {
    const user = users.find(u => u.username === username && u.password === password);
    if (!user) {
      return done(null, false);
    }
    return done(null, user);
  }
));

passport.serializeUser(function(user, done) {
  done(null, user.id);
});

passport.deserializeUser(function(id, done) {
  const user = users.find(u => u.id === id);
  if (!user) {
    return done(new Error('Такого пользователя нет!'));
  }
  done(null, user);
});

app.get('/login', function(req, res) {
  res.send(`
    <style>
      body {
        font-family: Arial, sans-serif;
        background-color: #f2f2f2;
      }
      
      form {
        width: 300px;
        margin: 0 auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      }
      
      input[type="text"],
      input[type="password"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 20px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
      }
      
      button[type="submit"] {
        width: 100%;
        padding: 10px;
        background-color: #ff69b4;
        color: #fff;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 16px;
      }
      
      button[type="submit"]:hover {
        background-color: #ff1493;
      }
    </style>
    
    <form method="post" action="/login">
      <input type="text" name="username" placeholder="Username" required>
      <input type="password" name="password" placeholder="Password" required>
      <button type="submit">Login</button>
    </form>
  `);
});

app.post('/login', passport.authenticate('local', {
  successRedirect: '/profile',
  failureRedirect: '/login'
}));

app.get('/logout', function (req, res){
  req.session.destroy(function (err) {
    res.redirect('/login');
  });
});

app.get('/profile', function(req, res) {
  if (!req.isAuthenticated()) {
    res.redirect('/login');
    return;
  }
  console.log(req.user)
  res.send(`
    <style>
      body {
        font-family: Arial, sans-serif;
        background-color: #ff69b4;
        text-align: center;
        padding: 20px;
      }
      
      h1 {
        color: #ff69b4;
        margin-bottom: 20px;
      }
      
      .user-info {
        background-color: #fff;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        display: inline-block;
      }
      
      .info-label {
        font-weight: bold;
      }
      
      .info-value {
        margin-top: 5px;
      }
    </style>
    
    <div class="user-info">
      <h1>Информация о пользователе</h1>
      <p class="info-label">Имя пользователя:</p>
      <p class="info-value">${req.user.username}</p>
      <p class="info-label">Идентификатор:</p>
      <p class="info-value">${req.user.id}</p>
    </div>
  `);
});

app.use(function(req, res) {
  res.status(404).send('Error 404. Page not found');
});

app.listen(3000, function() {
  console.log('Сервер работает на порте 3000');
});
