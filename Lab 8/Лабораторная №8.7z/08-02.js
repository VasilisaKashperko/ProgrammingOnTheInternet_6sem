const express = require('express');

const bodyParser = require('body-parser'); // для обработки тела запроса в формате JSON

const jwt = require('jsonwebtoken');

const app = express();
const port = 3000;

const users = require('./users.json');

const secret = 'vasilisa';

app.use(bodyParser.json());

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const user = users.find(user => user.username === username && user.password === password);
  if (!user) {
    return res.status(401).json({ message: 'Неправильный логин или пароль' });
  }
  const token = jwt.sign({ username }, secret, { expiresIn: '10m' });
  res.json({ token });
});

function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Невалидный токен' });
  }

  jwt.verify(token, secret, (err, decoded) => {
    if (err) {
      return res.status(401).json({ message: 'Невалидный токен' });
    }
    req.user = decoded;
    next();
  });
}

app.get('/profile', authenticateToken, (req, res) => {
  const { username } = req.user;
  res.json({ message: 'Авторизирован!', username });
});

app.use((req, res) => {
  res.status(404).send('Error 404. Not Found');
});

app.listen(port, () => {
  console.log(`Сервер работает на порту ${port}`);
});
